import { StyleSheet, Text, View } from "react-native";
import App from "./App";

export default function Page() {
  return (
      <View>
          <App />
          
      </View>
  );
}
